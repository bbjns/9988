function calculate() {
  const rate = parseFloat(document.getElementById('rate').value) || 0;
  const fee = parseFloat(document.getElementById('fee').value) || 0;
  const slippage = parseFloat(document.getElementById('slippage').value) || 0;
  const leverage = parseFloat(document.getElementById('leverage').value) || 1;
  const amount = parseFloat(document.getElementById('amount').value) || 0;
  const period = parseFloat(document.getElementById('period').value);

  const cycle_hours = period; // 1h / 4h / 8h
  const rate_per_cycle = rate / 100;
  const total_fee = (fee + slippage) / 100;
  const gross = leverage * rate_per_cycle;
  const net = gross - total_fee;
  const profit = amount * net;

  const day_profit = net * (24 / cycle_hours);
  const year_profit = day_profit * 365;
  const arbitrage = net > 0 ? "✅ 可套利" : "❌ 不建议套利";

  document.getElementById('result').innerHTML = `
    <p><strong>周期：</strong>每 ${cycle_hours} 小时</p>
    <p><strong>${arbitrage}</strong></p>
    <p>净收益率：${(net*100).toFixed(4)}%</p>
    <p>日化收益率：${(day_profit*100).toFixed(4)}%</p>
    <p>年化收益率：${(year_profit*100).toFixed(2)}%</p>
    <p>净利润（USDT）：${profit.toFixed(4)}</p>
  `;
}
